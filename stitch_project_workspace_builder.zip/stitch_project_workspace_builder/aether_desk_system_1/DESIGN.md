---
name: Aether Desk System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#0058be'
  on-secondary: '#ffffff'
  secondary-container: '#2170e4'
  on-secondary-container: '#fefcff'
  tertiary: '#005a82'
  on-tertiary: '#ffffff'
  tertiary-container: '#0074a6'
  on-tertiary-container: '#e4f2ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#89ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
    letterSpacing: 0em
  label-lg:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.125rem
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.02em
  tabular-data:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.125rem
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.5rem
  gutter-desktop: 0.75rem
  margin: 0.5rem
  margin-desktop: 1rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style
The design system establishes a high-precision, technical operating environment for web-based data management, synthesizing the structural rigor of Windows 11 File Explorer with the refined typography and optical lightness of macOS Finder. It is tailored for engineers, system administrators, knowledge workers, and technical power users who demand density, tactile feedback, and total spatial predictability.

The aesthetic philosophy centers on **Precision Functionalism**:
- **Visual Calmness**: Chrome and navigational surfaces recede into the canvas, ensuring that user data, file trees, and previews remain the visual focal point.
- **Instrument-Grade Density**: Tight, compact element geometries calibrated for mouse-driven and high-cadence keyboard navigation rather than touch-first bloat.
- **Physical Precision**: Borders are crisp and razor-thin (1px hairline), surfaces feature subtle structural shifts rather than heavy fills, and micro-elevation conveys instant tactile responsiveness.

## Colors
The color architecture relies on a surgical separation of structural chrome, informative neutrals, and high-legibility state indicators.

### Light Mode Architecture
- **Base Canvas (`surface-ground`)**: `#F8F9FA` establishes a low-glare workspace backdrop.
- **Raised Panels (`surface-panel`)**: `#FFFFFF` provides clean contrast for data grids, navigation sidebars, and detail inspectors.
- **Structural Hairstyle Outlines (`border-subtle`)**: `#E2E8F0` defines non-intrusive container separations.
- **Active Structural Outlines (`border-bold`)**: `#CBD5E1` delineates interactive states, column dividers, and active pane perimeters.
- **High-Contrast Typography (`text-primary`)**: `#0F172A` offers absolute contrast for filenames, metadata, and core labels.
- **Support Typography (`text-secondary`)**: `#334155` handles table headings and structural subheaders.
- **Muted Readouts (`text-muted`)**: `#64748B` covers secondary metadata (timestamps, file permissions, file sizes).
- **Interactive Action Blue (`accent-primary`)**: `#2563EB` handles primary actions, dropzone indicators, and focus rings.
- **Selection Low-Wash (`selection-tint`)**: `#EFF6FF` provides row and grid item selection without vibrating against dark text.
- **Selection Border Highlight (`selection-border`)**: `#DBEAFE` provides an optical crisping edge for selected assets.

### Dark Mode Complement
- **Base Canvas (`surface-ground`)**: `#0F172A` delivers an ultra-deep, anti-glare canvas.
- **Raised Panels (`surface-panel`)**: `#1E293B` isolates workspaces and inspector trays.
- **Structural Hairstyle Outlines (`border-subtle`)**: `#334155` creates sharp boundaries without high contrast.
- **Interactive Action Blue (`accent-primary`)**: `#3B82F6` shifts to a higher luminance level for contrast against dark surfaces.
- **Selection Low-Wash (`selection-tint`)**: `#1E3A8A33` (subtle 20% alpha wash).

## Typography
Typographic scale is compressed to support intense data densities without sacrificing scanning performance. 

- **Primary Stack**: `Inter`, `-apple-system`, `BlinkMacSystemFont`, `Segoe UI`, sans-serif.
- **Tabular Alignment**: All sizes, item counts, timestamps, and hash representations must explicitly apply `font-feature-settings: "tnum" 1, "cv05" 1` to guarantee rigid horizontal alignment across dynamic updating lists.
- **Hierarchy Rules**: Display headings are restricted to small increments (maximum 20px) to prevent layout shifting between breadcrumb states and deep directory paths.
- **Truncation**: File labels enforce `text-overflow: ellipsis` middle or trailing truncation, paired with full path indicators within system tooltips.

## Layout & Spacing
The layout adheres to a fixed-and-fluid hybrid architecture optimized for desktop-class file exploration:

### Structure Layout
- **App Shell Framework**: Three-pane partition model:
  1. *Source Tree Navigation (Left)*: Fixed minimum (220px), resizable up to 380px.
  2. *Main Data Workspace (Center)*: Fluid expansion, handling multi-column detailed tables, thumbnail grids, or column views.
  3. *Detail / Preview Inspector (Right)*: Collapsible, bounded between 280px and 440px.
- **Header Dock**: Fixed height 44px top utility band integrating navigation controls, breadcrumbs, search, and view switchers.
- **Status Bar**: Fixed height 24px footer anchored to the bottom edge displaying active volume quotas, selection count, and item aggregates.

### Spacing Discipline
A disciplined 4px base increment governs all internal layout gaps. Component padding prioritizes spatial efficiency:
- List rows maintain a default vertical height of 28px (compact mode) to 36px (standard mode).
- Grid item spacing defaults to `space-sm` (8px) for maximum spatial throughput.

## Elevation & Depth
Elevation abandons broad, multi-layered drop shadows in favor of mechanical layer stacking and hairline borders, utilizing micro-shadows strictly for floating overlays.

- **Level 0 (Base Canvas)**: Flat `#F8F9FA`, no shadow, 0px elevation.
- **Level 1 (Structural Panes)**: `#FFFFFF` encased in a 1px solid `#E2E8F0` hairline border. Separation is structural, not elevated.
- **Level 2 (In-Canvas Controls & Hover States)**: `box-shadow: 0 1px 2px 0 rgba(15, 23, 42, 0.04)`. Used for active toolbar segments, search bars, and focused inline controls.
- **Level 3 (Context Menus & Popovers)**: Refined desktop micro-elevation:
  `box-shadow: 0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.06), 0 0 0 1px rgba(15, 23, 42, 0.06)`.
- **Level 4 (Modal Dialogs & File Transfers)**: High-clarity focal shadow:
  `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.08), 0 0 0 1px rgba(15, 23, 42, 0.08)`.

## Shapes
Geometry uses clean, controlled radii to reflect technical precision:

- **Controls & Small Components (Inputs, Buttons, Tree Items)**: `6px` (`rounded-sm`). Produces balanced, modern desktop-grade touch targets that do not encroach on adjacent items.
- **Panels, Trays, Popovers, and Dropdown Menus**: `8px` (`rounded-md`). Enforces sharp visual containment for floating context windows.
- **Cards, Preview Modules, and File Tiles**: `10px` to `12px` (`rounded-lg`). Softens media frames without feeling playful or consumer-centric.
- **System Dialogs & Operational Overlays**: `14px` to `16px` (`rounded-xl`).
- **Pill Badges & Tag Micro-indicators**: Fully rounded (`9999px`) to create clear visual separation from rectilinear file rows.

## Components

### Buttons & Toolbars
- **Standard Button**: 28px or 32px height, 1px solid border (`#CBD5E1`), background `#FFFFFF`, text `#0F172A`, 6px corner radius. Padding: 0 10px. Hover: background `#F8F9FA`, border `#94A3B8`.
- **Primary Action**: 32px height, background `#2563EB`, text `#FFFFFF`, borderless with inner highlight: `inset 0 1px 0 0 rgba(255, 255, 255, 0.2)`. Hover: `#1D4ED8`.
- **Ghost/Icon Button**: Transparent background, 0px border, 28x28px box. Hover: background `#F1F5F9`, border-radius 6px.
- **Segmented View Switcher**: Grouped container with 1px hairline border `#E2E8F0` and `#F1F5F9` background. Inner active button carries `#FFFFFF` fill and a micro-shadow.

### Inputs & Breadcrumbs
- **Path/Breadcrumb Bar**: 32px height, `#FFFFFF` fill, 1px border `#CBD5E1`. Interactive directory segments show hover highlighting (`#F1F5F9`), separated by `/` or chevron glyphs (`#94A3B8`). Clicking open space transforms the path bar into a raw monospaced text input.
- **Global Search Input**: Inset search icon (`#64748B`), clear button on input, inline keyboard shortcut tag (`⌘K` or `Ctrl+K`) anchored right.

### List & Table Views
- **Header Row**: 28px height, `#F8F9FA` background, uppercase 11px label font (`label-sm`), separated by draggable vertical hairline resize handles (`#CBD5E1`).
- **Data Rows**: Standard 32px height. Alternating rows disabled; state driven entirely by selection:
  - *Hover*: Background `#F8F9FA`.
  - *Selected*: Background `#EFF6FF`, 1px outline or border `#DBEAFE`.
  - *Drop Target*: Background `#DBEAFE`, dashed 1px blue border `#2563EB`.
- **Cell Alignment**: Primary filename left-aligned with 16px file icon; size, modified date, and permissions right-aligned using tabular figures.

### Checkboxes & Selection Controls
- **File Row Checkbox**: 14x14px square, 3px border radius, 1px border `#94A3B8`. Checked state: `#2563EB` fill with white SVG checkmark. Appears on row hover or remains visible when rows are selected.

### Context Menus & File Cards
- **Context Menus**: Native OS layout emulation. Minimum width 180px, padding 4px. Menu items 26px height, font size 12px, rounded 4px. Keyboard shortcut indicator aligned right with `#64748B`. Dividers: 1px hairline `#E2E8F0`, margin 4px 0.
- **Grid Card View**: Fixed aspect ratio file tile (e.g., 120x130px). 8px radius. Upper region holds centered file-type vector or image thumbnail; lower region contains 2-line truncated centered text with subtle file extension badge.

### Transfer & Operational Dialogs
- **Transfer Drawer**: Anchored bottom-right, floating 340px width. Features real-time SVG progress rings or miniature 4px high track progress bars (`#2563EB` fill on `#E2E8F0` track), current speed transfer rates in `tabular-data` style, and instant cancel/pause buttons.