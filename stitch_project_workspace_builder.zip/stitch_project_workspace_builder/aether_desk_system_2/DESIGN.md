---
name: Aether Desk System
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#4648d4'
  on-secondary: '#ffffff'
  secondary-container: '#6063ee'
  on-secondary-container: '#fffbff'
  tertiary: '#006242'
  on-tertiary: '#ffffff'
  tertiary-container: '#007d55'
  on-tertiary-container: '#bdffdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#e1e0ff'
  secondary-fixed-dim: '#c0c1ff'
  on-secondary-fixed: '#07006c'
  on-secondary-fixed-variant: '#2f2ebe'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.006em
  body-default:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-medium:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  body-tabular:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-default:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.005em
  caption-micro:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.01em
  code-mono:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.375rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style
The design system establishes a high-performance, desktop-native workspace paradigm engineered for file management, cloud storage navigation, and technical digital asset operations. Drawing foundational structural clarity from macOS Finder and ergonomic information density from Windows 11 File Explorer, it rejects decorative bulk in favor of razor-sharp efficiency, spatial predictability, and absolute visual composure.

The visual tone is restrained, surgical, and premium: crisp 1px structural dividers, high-fidelity micro-interactions, low-latency visual feedback, and intentional typography calibrated specifically for dense data scanning. Users experience this interface not as an ephemeral web page, but as a robust, native-grade desktop utility that respects cognitive bandwidth during high-frequency file manipulation, metadata inspection, and complex directory traversal.

## Colors
The color architecture utilizes a balanced slate-zinc spectrum to minimize visual fatigue during sustained productivity, supplemented by high-chroma functional badges for immediate file-type identification.

- **Base Canvas & Surfaces**:
  - Main Window Background: `#f8fafc` (slate-50)
  - Active Content Panels, Cards & Data Grids: `#ffffff`
  - Sidebar & Secondary Inspector Surface: `#f1f5f9` (slate-100)
  - Subtle Borders & Interior Gridlines: `#e2e8f0` (slate-200)
  - Darkened Inset Borders / Active Splitters: `#cbd5e1` (slate-300)

- **Typography & Neutrals**:
  - Primary Labels & High-Contrast Titles: `#0f172a` (slate-900)
  - Secondary Metadata, Column Headers & Dates: `#64748b` (slate-500)
  - De-emphasized Captions & Placeholder Text: `#94a3b8` (slate-400)

- **Primary Interactive Brand Tokens**:
  - Primary Accent: `#2563eb` (Royal Blue)
  - Primary Hover: `#1d4ed8`
  - Focused Selection Tint (Row / Item highlight): `#eff6ff` (blue-50)
  - Multi-select Perimeter / Focus Ring: `rgba(37, 99, 235, 0.35)`

- **Functional Category Identifiers**:
  - PDF & Urgent Attention: `#ef4444` (Crimson)
  - Spreadsheets, Data & Success States: `#10b981` (Emerald)
  - Presentations, Storage Ceilings & Warnings: `#f59e0b` (Amber)
  - Code Repositories & Vector Assets: `#6366f1` (Indigo)
  - Media, Video Containers & Archival: `#8b5cf6` (Violet)

## Typography
Typographic scale is structured explicitly around desktop compactness and rapid data assimilation. The system strictly adopts `Inter` with OpenType tabular numeric figures (`font-variant-numeric: tabular-nums;`) across file size summaries, timestamps, item counts, and storage counters to ensure vertical alignment down columns.

- **Micro Scale (11px / 14px Line Height)**: Shortcut chips, file extension tags, badge counters, and secondary metadata captions.
- **System Secondary (12px / 16px Line Height)**: Table column sorting headers, breadcrumb roots, status bar summaries, and sidebar section headers (`text-transform: uppercase`, `letter-spacing: 0.05em`).
- **Core Workspace (13px / 18px Line Height)**: The operational workhorse. Applied to file names, folder items, metadata inspection rows, context menu items, and input values.
- **Navigation & Inputs (14px / 20px Line Height)**: Toolbar command buttons, global search bar text, and modal input field titles.
- **Panel Titles & Headers (16px - 18px / 22px - 24px Line Height)**: View titles, preference modals, and inspection drawer headers.

## Layout & Spacing
The layout implements a rigid, multi-pane desktop architecture that adapts from comprehensive triple-pane widescreen displays down to stacked hybrid views on compact viewports:

- **Sidebar (Collapsible)**: Fixed 240px default (resizable 180px–360px) utilizing `space-xs` (4px) vertical item separation and `space-md` (8px) horizontal padding.
- **Primary Content Viewport**: Fluid pane featuring toggleable modes: Detailed List, Multi-Column Hierarchy, or Grid View (120px to 220px dynamic card sizes).
- **Inspection Inspector Drawer**: 280px docking panel on the right flank, detailing file properties, permissions, and checksums.
- **Top Unified Command Bar**: 44px fixed height housing navigation controls, breadcrumbs, search engine, and action triggers.
- **Status Bar**: 28px fixed height pinned to the base, providing live aggregate stats (selected item count, free storage capacity, network syncing status).
- **Vertical Rhythm**: Built upon a strict 4px sub-grid (`space-xs: 4px`, `space-sm: 6px`, `space-md: 8px`, `space-lg: 12px`, `space-xl: 16px`).

## Elevation & Depth
Depth in the design system is engineered through structural layering and crisp 1px borders rather than blurry elevations, keeping file boundaries unambiguous:

- **Layer 0 (Canvas Base)**: `#f8fafc` flat background for the root desktop canvas.
- **Layer 1 (Panels & Toolbars)**: `#ffffff` bounded by `1px solid #e2e8f0`. Zero ambient blur.
- **Layer 2 (Draggable Cards & Item Selections)**: `#ffffff` resting over `#f8fafc`, cast with `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.05)`.
- **Layer 3 (Modals, Overlays & Drag Previews)**: Floating file drag ghosts and modal configurations have `box-shadow: 0 4px 12px -2px rgba(15, 23, 42, 0.08), 0 2px 6px -1px rgba(15, 23, 42, 0.04)`.
- **Layer 4 (Context Menus & Floating Upload Trays)**: High-altitude popovers leverage a razor border paired with deep ambient diffusion: `box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.10), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.

## Shapes
Geometry uses clean, controlled radii engineered to maintain high spatial efficiency without appearing harsh or brutalist:

- **Radius 6px (`rounded-sm` / badges, pills, inline tags)**: Extension badges, shortcut hint tags (`⌘K`), filter pills, and small input fields.
- **Radius 8px (`rounded` / buttons & row selections)**: List selection boundaries, toolbar buttons, toggle segments, and form elements.
- **Radius 10px (`rounded-md` / panels & cards)**: Content cards, file preview widgets, and primary modal containers.
- **Radius 12px (`rounded-lg` / floating menus)**: Right-click context menus, auto-complete dropdowns, and toast notifications.

## Components

### Navigation Toolbar & Breadcrumbs
- **Breadcrumb Navigator**: Inline segmented path. Segments use `12px` font with `#64748b`, transitioning to `#0f172a` on hover. Separated by `12px` chevron glyphs. Clicking any folder segment opens an instantaneous dropdown directory tree.
- **Global Search Field**: Compact 32px height container, `#ffffff` background with `1px solid #cbd5e1`. Houses an integrated keyboard shortcut badge (`⌘K`) right-aligned with 6px border radius, `#f1f5f9` fill, and `#64748b` typography.

### Data Grid & File List Items
- **Table Rows**: Strict 36px height (compact: 28px, relaxed: 44px). Column fields use tabular numerals for sizes (`14.2 MB`) and dates (`2025-05-12 14:32`).
- **Selection States**: Selected rows receive background `#eff6ff`, border-left `2px solid #2563eb`, and item labels transition to `#1d4ed8` medium weight. Multiple selections display an active blue perimeter.

### Buttons & Action Triggers
- **Primary Action**: Solid `#2563eb` fill, `#ffffff` text, 8px radius, height 32px, horizontal padding 12px. Hover: `#1d4ed8`. Focus: `0 0 0 2px rgba(37, 99, 235, 0.25)`.
- **Ghost/Tertiary Toolbar Buttons**: Transparent background, `#475569` text, transitioning to `#f1f5f9` fill on hover with `#0f172a` text.

### Context Menus & Floating Overlays
- **Menu Container**: Fixed minimum width 200px, 12px radius, `#ffffff` background, `1px solid #e2e8f0`, Layer 4 elevation.
- **Menu Item**: 28px height, 6px interior radius, flex layout with icon (16px), label (`13px`), and trailing shortcut keys (`11px` mono). Hover state sets background to `#2563eb` and text to `#ffffff`.

### Functional Badges & Progress Indicators
- **Type Badges**: 20px height, 6px radius, uppercase 11px font weight 600. Employs soft tinted backgrounds (e.g., `#fee2e2` with `#b91c1c` text for PDF; `#dcfce7` with `#15803d` for Spreadsheets).
- **Upload / Sync Bar**: 4px track height with `#e2e8f0` background; active progress indicator filled with `#2563eb`.