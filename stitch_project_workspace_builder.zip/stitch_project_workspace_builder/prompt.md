PROJECT: Professional Web File Manager

Design a complete, production-quality web-based file manager that feels like a modern desktop file-management application running inside a browser.

The product should combine the strongest usability patterns of Windows 11 File Explorer and macOS Finder, while having a completely original visual identity.

This is a UI/UX and prototype design project.

Do NOT design a generic SaaS dashboard.

The primary experience should feel like:

«A premium desktop file manager, rebuilt for the modern web.»

---

1. PRODUCT GOAL

The application allows users to:

- Browse files and folders
- Navigate folder hierarchies
- Search files
- Upload files and folders
- Create folders
- Rename files
- Move and copy items
- Download files
- Delete and restore files
- Preview files
- View file information
- Organize favorites
- Access recent files
- Access shared files
- Monitor storage
- Change application settings

The interface should prioritize speed, familiarity, discoverability and information density.

---

2. DESIGN PRINCIPLES

Follow these principles throughout EVERY screen:

Familiar

Users familiar with Windows Explorer or macOS Finder should immediately understand the interface.

Professional

The product should look suitable for a serious commercial application.

Minimal

Avoid unnecessary decoration.

Information-rich

Show useful metadata without creating visual clutter.

Fast

The UI should visually communicate quick interactions and low friction.

Consistent

Every screen must use the same:

- Typography
- Spacing
- Colors
- Borders
- Radius
- Icons
- Buttons
- Menus
- Interaction patterns

Desktop-first

The primary experience is desktop/laptop.

Tablet and mobile layouts should adapt intelligently rather than simply shrinking the desktop interface.

---

3. VISUAL IDENTITY

Create an original design inspired by modern operating systems.

Do NOT directly copy:

- Microsoft branding
- Apple branding
- Windows logos
- macOS logos
- Proprietary icons
- Exact Microsoft/Apple UI elements

Instead create a new visual language with similar usability principles.

The visual personality should be:

Clean + Calm + Premium + Technical + Friendly

Avoid:

- Excessive gradients
- Neon colors
- Excessive glassmorphism
- Huge typography
- Excessive rounded cards
- Generic dashboard layouts
- Excessive shadows
- Excessive animations

---

4. DESIGN SYSTEM — ESTABLISH FIRST

Before generating individual screens, establish a unified design system.

Create a reusable visual language containing:

Typography

Use a modern system-style sans-serif font.

Typography hierarchy:

- Application title
- Page title
- Section title
- File/folder name
- Metadata
- Helper text
- Caption

Keep typography compact and desktop-oriented.

---

Spacing

Use a consistent spacing scale.

Prefer approximately:

4 / 8 / 12 / 16 / 20 / 24 / 32 px

Avoid arbitrary spacing between components.

---

Border Radius

Use moderate rounding.

Suggested:

- Small controls: 6–8px
- Buttons: 8px
- Cards: 10–12px
- Dialogs: 14–16px

Do not make everything extremely rounded.

---

Borders

Use subtle 1px borders for:

- Panels
- Inputs
- Tables
- Cards
- Dialogs

Borders should create hierarchy without becoming visually heavy.

---

Shadows

Use soft, subtle shadows only for floating elements:

- Dropdowns
- Context menus
- Dialogs
- Popovers
- Floating panels

Avoid heavy shadows.

---

5. COLOR SYSTEM

Create both:

Light Theme

Use:

- Soft neutral background
- White/near-white content surfaces
- Neutral gray borders
- Dark primary text
- Muted secondary text
- One restrained accent color

Dark Theme

Use:

- Deep neutral background
- Slightly lighter surfaces
- Subtle borders
- High-contrast primary text
- Muted secondary text
- Same accent color adapted for dark mode

The accent color should be used primarily for:

- Selected items
- Active navigation
- Primary buttons
- Focus states
- Progress
- Links

Do not use many competing accent colors.

---

6. ICON SYSTEM

Use one consistent icon family.

Prefer simple outline icons with consistent stroke weight.

Required icons include:

- Back
- Forward
- Up
- Refresh
- Search
- Folder
- File
- Download
- Upload
- Share
- Delete
- Rename
- Copy
- Move
- More
- Sort
- Filter
- Grid
- List
- Settings
- Star
- Clock
- Cloud
- Storage
- Lock
- Info
- Check
- Warning
- Close

Do NOT use emoji as primary interface icons.

---

7. GLOBAL APPLICATION SHELL

Create a reusable application shell.

Structure:

┌──────────────────────────────────────────────────────────────┐
│                    TOP APPLICATION BAR                       │
├────────────────┬─────────────────────────────────────────────┤
│                │                                             │
│                │                                             │
│    SIDEBAR     │              MAIN CONTENT                   │
│                │                                             │
│                │                                             │
│                │                                             │
│                │                                             │
├────────────────┴─────────────────────────────────────────────┤
│                        STATUS BAR                            │
└──────────────────────────────────────────────────────────────┘

The shell should remain consistent across all screens.

---

8. TOP TOOLBAR

Create a reusable toolbar containing:

Navigation

- Back
- Forward
- Up
- Refresh

Breadcrumb

Example:

Home / Documents / Projects / Website

Breadcrumb items should be interactive.

Search

Large integrated search box:

Search files and folders

Include:

- Search icon
- Keyboard shortcut hint
- Clear button
- Focus state
- Search suggestions

Actions

Include:

- New
- Upload
- Sort
- Filter
- View mode
- More

---

9. SIDEBAR

Create a collapsible sidebar approximately 240–280px wide.

Sections:

Favorites

- Home
- Desktop
- Documents
- Downloads
- Pictures
- Music
- Videos

Locations

- This Computer
- Local Storage
- Cloud Storage
- Shared
- Recent

Tags

- Important
- Work
- Personal
- Projects

Storage

Show:

Storage

342 GB used
512 GB total

██████████████░░░░

Include:

Manage Storage

Sidebar states:

- Default
- Hover
- Active
- Focused
- Collapsed
- Drag target

---

10. SCREEN 01 — HOME

Create the primary Home screen.

Show:

Quick Access

Large folder shortcuts:

- Documents
- Downloads
- Pictures
- Desktop

Recent Files

Show recently opened files.

Favorites

Show pinned files/folders.

Storage summary

Show current storage usage.

The Home screen should feel useful rather than decorative.

---

11. SCREEN 02 — FILE EXPLORER / FOLDER

Create the main folder browsing experience.

Example:

Home / Documents

                    + New    Upload   Sort   ▦

Folders

Documents
Projects
Reports

Files

Resume.pdf
Budget.xlsx
Presentation.pptx
Notes.docx

Support:

- Grid view
- List view
- Selection
- Sorting
- Filtering
- Breadcrumb navigation

---

12. SCREEN 03 — GRID VIEW

Create a premium file grid.

Folder cards:

📁
Documents

File cards:

[thumbnail/icon]

Resume.pdf
2.4 MB

Cards must support:

- Hover
- Selected
- Focus
- Dragging
- Context menu
- Multi-selection

Keep cards compact enough to display many files.

---

13. SCREEN 04 — LIST VIEW

Create a detailed list.

Columns:

Name
Date Modified
Type
Size

Include:

- Folder/file icons
- File thumbnails where useful
- Sort indicators
- Row hover
- Row selection
- Multi-select
- Sticky header

The list should look like a premium desktop file manager, not a spreadsheet.

---

14. SCREEN 05 — SEARCH

Create a complete search experience.

When searching:

Search: presentation

Show:

Files

- Presentation.pptx
- Presentation-final.pdf

Folders

- Presentations

Add filter chips:

- Type
- Date
- Size
- Location

Show search result count.

Create a clear "No results" state.

---

15. SCREEN 06 — RECENT

Create a Recent Files screen.

Group files by:

- Today
- Yesterday
- Earlier this week
- Earlier this month

Display:

- Thumbnail/icon
- Name
- Location
- Modified date
- Type
- Size

---

16. SCREEN 07 — FAVORITES

Create a Favorites screen.

Show:

- Pinned folders
- Pinned files

Allow visual controls for:

- Remove from Favorites
- Open
- Rename
- Share
- More actions

---

17. SCREEN 08 — SHARED

Create a Shared Files screen.

Columns:

Name
Owner
Shared With
Permission
Modified

Permission badges:

- Viewer
- Editor
- Owner

Include avatar placeholders for shared users.

---

18. SCREEN 09 — TRASH

Create a Trash / Recycle Bin screen.

Show:

- Deleted item
- Original location
- Deleted date
- Size

Actions:

- Restore
- Delete permanently
- Empty Trash

Include appropriate confirmation dialogs.

---

19. SCREEN 10 — FILE PREVIEW

When selecting a supported file, show a right-side preview panel.

Support conceptual previews for:

- Images
- PDFs
- Videos
- Text documents

Panel:

Preview                         ×

[ FILE PREVIEW ]

Resume.pdf
PDF Document

Modified
Today, 10:32 AM

Size
2.4 MB

Location
Documents / Work

Include:

- Open
- Download
- Share
- More

Allow the preview panel to be resized.

---

20. SCREEN 11 — FILE INFORMATION

Create a detailed information/properties panel.

Show:

- File name
- File type
- Size
- Created
- Modified
- Location
- Dimensions if image
- Duration if video
- Sharing
- Permissions

Use a clean information hierarchy.

---

21. SCREEN 12 — UPLOAD

Create an upload experience.

Normal state:

Upload

Dropdown:

Upload Files
Upload Folder

Drag-and-drop state:

Drop files here

Create a full-screen or large-area drag overlay.

---

22. SCREEN 13 — UPLOAD PROGRESS

Create an upload queue.

Example:

Uploading 3 files

Resume.pdf
████████████████░░░ 87%

Project.zip
██████████░░░░░░░░░ 52%

Photo.jpg
Completed ✓

States:

- Uploading
- Paused
- Completed
- Failed
- Cancelled

Actions:

- Pause
- Resume
- Cancel
- Retry

---

23. SCREEN 14 — NEW FOLDER

Create a modal:

New Folder

Folder name

[ My New Folder ]

Cancel       Create

Include:

- Default focus
- Validation
- Error state
- Loading state
- Success state

---

24. SCREEN 15 — CONTEXT MENUS

Design context menus for:

File

Open
Preview
Open With
────────────
Download
Share
Copy
Move
Rename
────────────
Add to Favorites
Get Info
────────────
Delete

Folder

Open
Open in New Tab
────────────
New File
New Folder
────────────
Copy
Move
Rename
Share
────────────
Add to Favorites
Get Info
Delete

Context menus should feel native and compact.

---

25. SCREEN 16 — MULTI-SELECTION

Create a state with several selected items.

Example:

3 items selected

Download   Share   Copy   Move   Delete   More

Show clear selection indicators.

---

26. SCREEN 17 — DELETE CONFIRMATION

Create:

Delete "Project Files"?

This item will be moved to Trash.

Cancel       Move to Trash

Create another version for permanent deletion:

This action cannot be undone.

---

27. SCREEN 18 — STORAGE

Create a storage management page.

Show:

Storage

512 GB total

342 GB used
170 GB available

Categories:

- Documents
- Images
- Videos
- Applications
- Other

Use an elegant visualization.

Do not make this look like an analytics dashboard.

---

28. SCREEN 19 — SETTINGS

Create a settings interface.

Categories:

General

- Default view
- Confirm deletion
- Open folders in new tab
- Show file extensions

Appearance

- Light
- Dark
- System
- Compact
- Comfortable

Files

- Default download location
- Sort preference
- Hidden files

Keyboard Shortcuts

Show shortcuts:

Ctrl/Cmd + A
Ctrl/Cmd + C
Ctrl/Cmd + X
Ctrl/Cmd + V
Ctrl/Cmd + F
F2
Delete
Enter
Backspace

---

29. SCREEN 20 — EMPTY STATES

Create reusable empty states.

Empty folder

[folder illustration]

This folder is empty

Upload files or create a new folder.

Upload     New Folder

No search results

[search illustration]

No files found

Try another search term.

No favorites

[star illustration]

No favorites yet

Pin files and folders to access them quickly.

---

30. SCREEN 21 — LOADING STATES

Create skeleton states for:

- Sidebar
- Toolbar
- File grid
- File list
- Preview panel
- Storage

Use subtle skeleton animation.

---

31. SCREEN 22 — ERROR STATES

Create:

Unable to load this folder

Something went wrong.

Try Again

And:

File unavailable

This file may have been moved or deleted.

Go Back

---

32. SCREEN 23 — MOBILE

Create a mobile adaptation.

Do NOT simply shrink the desktop UI.

Use:

- Compact top bar
- Sidebar drawer
- Bottom navigation if appropriate
- Mobile-friendly file cards
- Floating New/Upload action
- Touch-friendly controls
- Bottom sheets instead of desktop context menus

Prioritize:

1. Navigation
2. Search
3. File browsing
4. Upload
5. Selection

---

33. SCREEN 24 — TABLET

Create a tablet layout.

Use:

- Collapsible sidebar
- Adaptive grid
- Compact toolbar
- Touch-friendly controls
- Optional preview panel

---

34. DARK MODE

Create a complete dark-mode version.

Do not simply invert the light theme.

Dark mode should have:

- Deep neutral background
- Elevated dark surfaces
- Subtle borders
- Clear selected states
- High-quality contrast
- Restrained accent color

---

35. INTERACTION PROTOTYPE

Connect the screens into a coherent prototype.

Important flows:

Flow A — Browse

Home → Documents → Project Folder → File

Flow B — Search

Home → Search → Search Results → File Preview

Flow C — Upload

Folder → Upload → Drag & Drop → Upload Progress → Completed

Flow D — Create Folder

Folder → New → New Folder → Created Folder

Flow E — Rename

File → Context Menu → Rename → Confirm

Flow F — Delete

File → Context Menu → Delete → Confirmation → Trash

Flow G — Restore

Trash → Select File → Restore → Original Folder

Flow H — Preview

Folder → Select File → Preview Panel → File Information

---

36. INTERACTION STATES

Every important component should have:

- Default
- Hover
- Pressed
- Focused
- Selected
- Disabled
- Loading
- Error
- Success

Make these states visually consistent across the entire application.

---

37. DRAG AND DROP

Create visual states for:

- Dragging file
- Dragging folder
- Drop target
- Invalid drop
- Moving item
- Uploading

The drop target should become visually obvious without overwhelming the interface.

---

38. NOTIFICATIONS

Create toast notifications for:

File uploaded successfully
Folder created
File renamed
3 files moved to Trash
File copied
Download started
Upload failed

Keep notifications compact and unobtrusive.

---

39. ACCESSIBILITY

Design for accessibility.

Include:

- Keyboard navigation
- Visible focus states
- Accessible labels
- Adequate contrast
- Touch-friendly hit targets
- Screen-reader-friendly hierarchy
- Reduced-motion support

---

40. SAMPLE DATA

Use realistic sample content.

Folders:

- Documents
- Projects
- Downloads
- Pictures
- Videos
- Music
- Work
- Personal
- Archive

Files:

- Resume.pdf
- Project Proposal.docx
- Budget.xlsx
- Presentation.pptx
- Vacation.jpg
- Demo.mp4
- Notes.txt
- Website.zip

Use realistic:

- File sizes
- Dates
- Locations
- File types

---

41. CONSISTENCY REQUIREMENT

This is extremely important:

All screens must look like they belong to ONE application.

Do not redesign the visual language between screens.

Reuse the same:

- Sidebar
- Toolbar
- Buttons
- Menus
- File cards
- File rows
- Dialogs
- Typography
- Spacing
- Colors
- Icons
- Radius
- Borders
- Shadows
- Interaction patterns

If a component already exists, reuse it instead of creating a visually different version.

---

42. COMPONENT-BASED THINKING

Design the interface as reusable components.

Important reusable components:

- AppShell
- Sidebar
- Toolbar
- Breadcrumb
- SearchBox
- FileGrid
- FileList
- FileCard
- FileRow
- FolderCard
- ContextMenu
- Dropdown
- Dialog
- Toast
- UploadPanel
- PreviewPanel
- PropertiesPanel
- StorageIndicator
- EmptyState
- Skeleton
- Tooltip

---

43. PROTOTYPE QUALITY

The prototype should communicate:

- How navigation works
- How files are selected
- How folders open
- How search works
- How menus appear
- How uploads progress
- How preview works
- How deletion works
- How responsive layouts behave

Use realistic interactions rather than static screens wherever possible.

---

44. FINAL VISUAL TARGET

The final result should feel like:

Windows 11 File Explorer
+
macOS Finder
+
Modern premium web application

But it must have an original visual identity.

The final design should make someone think:

«"This looks like a real professional operating-system-level file manager."»

not:

«"This looks like another web dashboard."»

Prioritize usability over decoration.

Prioritize consistency over novelty.

Prioritize professionalism over visual effects.

---

45. IMPORTANT DEVELOPMENT HANDOFF

The UI will later be implemented by a separate AI/development system.

Therefore:

- Keep layouts structurally clear
- Use reusable components
- Keep interactions logically defined
- Avoid unnecessary visual complexity
- Make states explicit
- Make responsive behavior clear
- Keep the design system consistent
- Make components easy to translate into React/Tailwind or similar frontend technology

Do NOT design backend architecture.

Do NOT design database architecture.

Do NOT design authentication flows unless required visually for future extensibility.

Focus on the file manager UI/UX, visual system and interactive prototype.

FINAL INSTRUCTION

First establish the global design system and application shell.

Then generate the screens using that same system.

The entire product should look as though it was designed by one senior product designer over a long period of time, not generated as unrelated individual screens.