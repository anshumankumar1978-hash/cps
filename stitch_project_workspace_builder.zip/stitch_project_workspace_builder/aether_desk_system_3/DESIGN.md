---
name: Aether Desk System
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#a4c9ff'
  on-secondary: '#00315d'
  secondary-container: '#0267b8'
  on-secondary-container: '#d6e5ff'
  tertiary: '#7bd0ff'
  on-tertiary: '#00354a'
  tertiary-container: '#009bd1'
  on-tertiary-container: '#002d40'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#d4e3ff'
  secondary-fixed-dim: '#a4c9ff'
  on-secondary-fixed: '#001c39'
  on-secondary-fixed-variant: '#004883'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  headline-lg:
    fontFamily: Geist
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.025em
  headline-md:
    fontFamily: Geist
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Geist
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.015em
  title-md:
    fontFamily: Geist
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-md:
    fontFamily: Geist
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Geist
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
  label-lg:
    fontFamily: Geist
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1.125rem
    letterSpacing: -0.005em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '400'
    lineHeight: 0.875rem
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system targets power users, creative directors, software engineers, and digital asset managers who require an uncompromising, workstation-grade web file manager. The brand personality is precise, architectural, unyielding, and whisper-quiet. The visual environment evokes the feeling of high-end system software: instant responsiveness, razor-sharp visual boundaries, and zero extraneous decorative noise. 

The aesthetic is rooted in **Precision Dark Minimalist Glass**—a hybrid of high-density productivity software and refined operating system interfaces:
- **Atmosphere:** Deep obsidian and slate foundations eliminate visual fatigue during sustained technical workflows.
- **Hierarchy:** High information density achieved via micro-spacing, structured bounding borders, and rigorous typographic discipline rather than dramatic scale jumps.
- **Focus:** Electric blue serves exclusively as an interactive vector—signaling active focus states, selection bounds, bulk actions, and data progression.
- **Tactility:** Crisp 1px structural dividers, frosted dropdown layers, and understated ambient backdrops provide immediate, physical spatial clarity.

## Colors

The palette is engineered for prolonged visual ergonomics and high contrast precision in deep dark environments.

### Surface Architecture
- **Base Canvas (`#0b0f19`):** Pure obsidian canvas for root application containers and external letterboxing.
- **Surface Level 1 (`#0f172a`):** Deep slate primary viewport for file grids, list canvases, and document inspection viewports.
- **Surface Level 2 (`#182234`):** Elevated sidebars, navigation panels, contextual tree-views, and persistent dock headers.
- **Surface Level 3 (`#1e293b`):** Modals, contextual menus, preview inspection cards, floating toolbars, and selected row highlights.
- **Surface Level 4 (`#334155`):** Chip backgrounds, hovered file rows, drag-and-drop targets, and inactive segment indicators.

### Accent & Active States
- **Electric Blue Primary (`#3b82f6`):** Explicitly reserved for active states, key action buttons, focus rings, selected file highlights, and active breadcrumbs.
- **Interactive Light (`#60a5fa`):** Secondary interactive tone applied to hover states of blue actions and download progress pulses.
- **Tertiary Cyan (`#38bdf8`):** Reserved for system-level telemetry, synchronization pins, and file metadata tagging (e.g., symlinks, shared status).

### Borders & Delimiters
- **Structural Border (`#334155`):** Explicit 1px divider for panels, splitters, tree views, and table headers.
- **Subtle Surface Border (`rgba(148, 163, 184, 0.08)`): Used inside floating card elements and glassmorphic overlays.

### Typography & Iconography
- **Primary Ink (`#f8fafc`):** Pure bright silver-white for file labels, headings, active breadcrumb items, and direct input text.
- **Secondary Ink (`#94a3b8`):** Balanced metallic slate for file metadata (dimensions, extensions, modified timestamps, table headers).
- **Muted Ink (`#64748b`):** Subdued tint for inactive placeholders, unselected item counts, and collapsed tree carets.

## Typography

The type system prioritizes micro-legibility and tabular efficiency, using **Geist** for structural interface elements and **JetBrains Mono** for data-heavy file parameters.

- **Scale Restraint:** Display sizes are deliberately capped at `1.75rem` (`28px`), matching native operating system desktop paradigms where information density takes precedence over editorial scale.
- **Monospace Integration:** All file sizes, timestamps, MIME types, permission strings (`drwxr-xr-x`), and cryptographic hashes must be rendered using `JetBrains Mono` via the `label-md` or `label-sm` tokens to ensure rigid tabular alignment in list views.
- **Truncation Standards:** File names must preserve character legibility with middle truncation (e.g., `production_build_..._v2.tar.gz`) instead of trailing ellipses to guarantee visibility of file extensions.

## Layout & Spacing

The layout is built as a multi-pane, application-style viewport filling 100% of the browser frame (`100vw` / `100vh`) with strictly non-scrolling global canvas boundaries. Inner scroll areas are distributed per pane.

### Pane Configuration & Rhythm
- **Navigation Drawer / Sidebar:** 240px to 280px fixed-width collapsible vertical region for drive trees, shared team folders, and bucket roots.
- **Central Viewport:** Fluid flex-grow container transitioning dynamically between tabular data grids, icon matrix views, and dual-pane comparative modes.
- **Inspector Pane:** 320px fixed-width collapsible sidebar displaying file metadata, preview waveforms, images, and access permissions.
- **Micro Spacing Scale:** Built on a tight 4px base multiplier. Internal component padding favors compact bounds (`space-xs` to `space-md`) to ensure high density without visual crowding.

### Adaptive Behavior
- **Desktop (1280px+):** Full multi-pane arrangement (Left Directory Tree, Center File Grid, Right Inspector Panel) simultaneously visible.
- **Laptop / Tablet Landscape (768px - 1279px):** Inspector pane moves into an off-canvas drawer accessed via a toolbar toggle button. Grid gutter drops to `0.5rem`.
- **Mobile (Below 768px):** Structural panels convert to bottom sheets. The directory tree transforms into an interactive breadcrumb drawer, prioritizing single-column list views for rapid single-handed thumb scanning.

## Elevation & Depth

Visual hierarchy is constructed through **Tonal Stacking**, **Crisp 1px Boundaries**, and **Frosted Backdrops** rather than muddy heavy drop shadows.

### Surface Tiers
- **Tier 0 (Root Level):** Deep obsidian canvas (`#0b0f19`) forming outer toolbars and app window headers.
- **Tier 1 (Base Panels):** Slate base (`#0f172a`) framed with `1px solid #334155` interior divider walls.
- **Tier 2 (Elevated Regions):** Cards, tree headers, and active selection states use `#182234` with subtle `0 1px 3px rgba(0, 0, 0, 0.45)`.
- **Tier 3 (Floating Overlays & Context Menus):** Translucent `#1e293b` with 80% opacity, paired with `backdrop-filter: blur(12px)` and a sharp hairline edge border (`rgba(255, 255, 255, 0.08)`).
- **Tier 4 (Modals & Command Palettes):** Layered `#1e293b` over a tinted scrim (`rgba(11, 15, 25, 0.75)`), accented by a refined ambient drop-shadow: `0 20px 25px -5px rgba(0, 0, 0, 0.6), 0 8px 10px -6px rgba(0, 0, 0, 0.6)`.

### Border Integrity
Every container division must rely on explicit 1px strokes rather than box-shadow bleed to maintain clear structural limits across varied monitor gamuts and dark workspaces.

## Shapes

The shape system employs an intentionally compact, technical contour range reflecting refined OS utilities.

- **Base Radius (6px / `0.375rem`):** Applied to buttons, input fields, contextual action pills, breadcrumb chips, and context menu items.
- **Card & Dialog Radius (8px / `0.5rem`):** Reserved for elevated surface cards, modal dialogues, floating toolbars, and inspector preview panes.
- **Micro Radius (4px / `0.25rem`):** Applied to list item selection states, tree row indicators, checkbox squares, and scrollbar thumbs.
- **Full Radius (9999px):** Strictly constrained to circular status dots, system notification badges, and active task count tags.

## Components

### Buttons
- **Primary:** Solid electric blue background (`#3b82f6`), text in `#f8fafc` (`label-lg`), height: 32px, horizontal padding: `space-md` (12px), border-radius: 6px. Hover: `#60a5fa`. Focus ring: 2px offset in `#3b82f6`.
- **Secondary / Surface:** Slate background (`#1e293b`), border: `1px solid #334155`, text: `#f8fafc`. Hover: `#334155`.
- **Ghost / Icon:** Transparent background, text: `#94a3b8`, 28px × 28px square bounding box. Hover: background `#1e293b`, icon: `#f8fafc`.

### Context Menus & Floating Toolbars
- **Container:** Frosted glass overlay (`rgba(30, 41, 59, 0.85)` with `backdrop-filter: blur(16px)`), border: `1px solid rgba(148, 163, 184, 0.12)`, shadow: `0 12px 24px -4px rgba(0, 0, 0, 0.5)`. Padding: `space-xs`.
- **Menu Item:** 28px height, flex alignment, gap: `space-sm`, border-radius: 4px, font: `body-md` (`#f8fafc`). Hover: `#3b82f6` with text `#ffffff`. Keyboard shortcut tags styled in `label-sm` (`#64748b`).

### File Lists & Table Rows
- **Layout:** High-density 32px or 36px row height with a 1px border bottom (`#182234`).
- **Default State:** Transparent background, text in `#f8fafc`.
- **Hover State:** Background tint `#182234`.
- **Selected State:** Background tint `rgba(59, 130, 246, 0.15)`, left indicator border: 2px solid `#3b82f6`. Text remains `#f8fafc`.

### File Grid Cards
- **Dimensions:** Compact aspect ratio cards with a fixed 120px × 90px preview container over a `#0f172a` canvas, nested within a `#182234` outer card.
- **Border:** 1px solid `#334155`.
- **Selection State:** Active border: `1px solid #3b82f6`, outer glow: `0 0 0 1px #3b82f6`.

### Form Inputs & Path Bars
- **Path Bar (Breadcrumbs):** Background `#0b0f19`, border: `1px solid #334155`, height: 32px. Interactive segment pills hover with `#1e293b`.
- **Search & Filters:** Inset background `#0b0f19`, placeholder text `#64748b`, active typed text `#f8fafc`. Active focus triggers a 1px border `#3b82f6`.

### Selection Checkboxes & Switches
- **Checkboxes:** 14px × 14px square box, 3px border-radius. Inactive: border `1px solid #64748b`, background `#0b0f19`. Active: background `#3b82f6`, border `#3b82f6`, white SVG check icon.
- **Progress Bars:** 4px line track (`#1e293b`) with animated fill (`#3b82f6`). High-transfer velocity or sync operations can transition to cyan (`#38bdf8`).